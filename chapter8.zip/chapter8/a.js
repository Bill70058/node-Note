/**
 * 依赖文件：3.jade
 * 作用：用于链入内部文件
 * 作者：biil
 */
<script>
window.onload = function() {
                document.querySelector('div').style.background='green'
            }
</script>