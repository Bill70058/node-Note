var express = require('express');
var server = express();
var static = require('express-static');

server.listen(1234);
// server.use('', function(req, res, next) {
//     res.cookie('user', '1234', {path: '/aaa'}, {maxAge: 1000});
//     res.send('ok');
// });
// server.use(static('./www'));

server.use('', function(req, res) {
    res.cookie('user', '1234', {maxAge: 5000});
    res.send('ok');
})