var express = require('express');
var static = require('express-static');
var cookieParser = require('cookie-parser');
var server = express();

 
server.listen(1234);
server.use(cookieParser());
server.use('', function(req, res, next) {
    //  res.send('ok');
    res.cookie('user', 'bill', {maxAge: 365*24*3600*1000});
    res.cookie('password', '123456', {maxAge: 365*24*3600*1000});
   // console.log(req.cookies);
    next();  
});

server.use('/home', function(req, res) {
    console.log(req.cookies);
    res.send({
        user: req.cookies.user,
        pass: req.cookies.password,
    });
});

server.use(static('./www'));

