var http = require('http'),
fs = require('fs'),
urlLib = require('url'),
querystring = require('querystring');

http.createServer(function(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    var json = urlLib.parse(req.url, true).query;

    console.log(json.user, json,pass);
}).listen(9217);